import {Customer} from './types'

const customer: Customer[] = [
    {id: 1, name: "mings", address: "abcabc", email: "dfddd@naver.com", description: "22222" },
    {id: 2, name: "hongs", address: "vcvcx", email: "dfdsf@naver.com", description: "22222" },
    {id: 3, name: "jeons", address: "dfdfdf", email: "fffff@naver.com", description: "22222" }
]

const databaseA = {
    customer 
}

export default databaseA;