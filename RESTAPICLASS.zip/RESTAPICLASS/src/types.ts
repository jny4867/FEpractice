export type Customer = {
    id: number;
    name: string;
    address?: string;
    email:string;
    description:string;
}